# DevSpeedEnabler
RimWorld mod

Dev speed is the fastest game speed and is only available when development mode is enabled. It can be toggled on by pressing the bound key, usually '4'. This mod allows the use of dev speed without development mode being enabled.

##Changelog:

###1.0:
* threw it together in a couple of hours
* things seem to work