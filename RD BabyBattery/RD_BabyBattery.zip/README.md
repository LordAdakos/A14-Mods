# BabyBattery
RimWorld mod

A smaller battery, 1x1, that costs the same as a large battery. It holds less charge but it is much more efficient at storing charge than a larger battery.

##Changelog:

###1.0:
* threw it together in 2-3 hours
* things seem to work
